import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  checkdata(e,p){
  	if(e.length > 0 && p.length > 0  ){
  		var email=localStorage.getItem('emailid');
  		var pass=localStorage.getItem('password');
  		if(email == e && pass == p){
  			// console.log('ok');
        localStorage.setItem('status',"done");
        this.router.navigate(['/']);
  		}
  		else{
  			console.log('invalide');
  		}

  	}
  	else{
  		console.log('please Enter Record');
  	}
  }

}
