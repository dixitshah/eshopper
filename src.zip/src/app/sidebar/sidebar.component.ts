import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import {CrudService} from'../crud.service'; 
@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
	public categorydata;
	public branddata;
  constructor(private crudoperation:CrudService) { 
  	// console.log(this.xyz);
  }

  ngOnInit() {
  	this.crudoperation.select("category").subscribe(
    		(category)=>{
    			// console.log(category.json());
    			this.categorydata=category;
    		}
	  );

  	this.crudoperation.select("brand").subscribe(
  		(brand)=>{
  			// console.log(brand.json());
  			this.branddata=brand;
  		}
  	)

  }

  filter_brand(id){
    // alert(id)
    this.crudoperation.filter_brand(id)
  }

}
