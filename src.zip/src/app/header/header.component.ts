import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
public URLSTATUS1 = true;
public URLSTATUS2 = true;
  constructor() { }

  ngOnInit() {
  	if(localStorage.status){
  		this.URLSTATUS1 = true;
  		this.URLSTATUS2 = false;
  	}
  	else{
  		this.URLSTATUS1 = false;
  		this.URLSTATUS2 = true;
  	}
  }

}
