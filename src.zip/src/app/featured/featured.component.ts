import { Http } from '@angular/http';
import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import {CrudService} from'../crud.service';
@Component({
  selector: 'app-featured',
  templateUrl: './featured.component.html',
  styleUrls: ['./featured.component.css']
})
export class FeaturedComponent implements OnInit {
public productdata;
public productdata1=[];
  constructor(private xyz:CrudService,private cart: CookieService) {
      // console.log(this.cart);

   }

  ngOnInit() {
  	this.xyz.select("product").subscribe(
  		(product)=>{
  			// console.log(category.json());
  			this.productdata=product;
  		}
	);


    this.xyz.dataSource.subscribe((res)=>{
      // console.log("feature=>"+res);
      this.xyz.select("product").subscribe(
      (product)=>{
        // console.log(product);
        this.productdata1=[]
        for(var ans in product){
          if(product[ans].brand_id == res){
            this.productdata1.push(product[ans])
          }
        }
        this.productdata=this.productdata1;
      }
    })
  }

  addtocart(id,e){
    // console.log(id);
     // console.log(e);
     e.preventDefault();
     var cookiedata=this.cart.get("product");
     if(cookiedata == ""){
       this.cart.set("product",id);  
     }
     else{
       var newdata=cookiedata+","+id;
       // console.log(newdata);
       this.cart.set("product",newdata);
      }
     alert("product Added");




  }

}
