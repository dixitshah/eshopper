import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Http } from '@angular/http';
@Component({
  selector: 'app-categoryfilter',
  templateUrl: './categoryfilter.component.html',
  styleUrls: ['./categoryfilter.component.css']
})
export class CategoryfilterComponent implements OnInit {

  constructor(private route: ActivatedRoute, private abc:Http) { 
  	// console.log(typeof this.route.params._value.xyz);


  }
  public productdata =[];
  ngOnInit() {
  	var id=this.route.snapshot.params.xyz;
  		this.abc.get("http://localhost:5000/product").subscribe(
  		(product)=>{
  			// console.log(product.json());
	  		var pro=product.json();
	  		for(var ans in pro){
	  			// console.log(ans);
	  			// console.log(typeof pro[ans]);
	  			// console.log(typeof pro[ans].category_id);
	  			if(pro[ans].category_id == Number(this.route.snapshot.params.xyz)){

	  				this.productdata.push(pro[ans]);
	  			}
	  		}	
	  		console.log(this.productdata);
  		}
	);


  }

}
