import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
private status:boolean;
  constructor() { }

  isLoggedIn(){
  	if(localStorage.status){
  		return 1;	
  	}
  }
  isnotLoggedIn(){
  	if(!localStorage.status){
  		return 1;	
  	}
  }
}
