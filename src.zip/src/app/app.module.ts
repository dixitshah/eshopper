
import {ReactiveFormsModule,FormsModule} from '@angular/forms';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { CookieService } from 'ngx-cookie-service';
import { CrudService } from './crud.service';
import { AuthService } from './auth.service';
import {AuthGuard} from './auth.guard';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { SliderComponent } from './slider/slider.component';

import { FeaturedComponent } from './featured/featured.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { CategoryfilterComponent } from './categoryfilter/categoryfilter.component';
import { BrandfilterComponent } from './brandfilter/brandfilter.component';
import { CartcomponentComponent } from './cartcomponent/cartcomponent.component';
import { AddcategoryComponent } from './addcategory/addcategory.component';
import { LogoutComponent } from './logout/logout.component';

const appRoutes: Routes = [
  { path: 'register', component: RegisterComponent , canActivate:[AuthGuard] },
  { path: 'login', component: LoginComponent , canActivate:[AuthGuard]},
  { path: '', component: FeaturedComponent },
  { path: 'categorydata/:xyz', component: CategoryfilterComponent },
  { path: 'branddata/:xyz', component: BrandfilterComponent },
  { path: 'cart', component: CartcomponentComponent },
  { path: 'addcategory', component: AddcategoryComponent },
  { path: 'logout', component: LogoutComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    SliderComponent,
    FeaturedComponent,
    LoginComponent,
    RegisterComponent,
    CategoryfilterComponent,
    BrandfilterComponent,
    CartcomponentComponent,
    AddcategoryComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,  
    ReactiveFormsModule,
    FormsModule,
     RouterModule.forRoot(
      appRoutes
    )
  ],
  providers: [CookieService,CrudService,AuthGuard,AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
