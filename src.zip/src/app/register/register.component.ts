import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,FormBuilder,Validators,NgForm} from '@angular/forms';
import {CrudService} from '../crud.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
	signupForm:FormGroup;
	status=false;
  constructor(private fbuilder:FormBuilder,private crud:CrudService) { }

  ngOnInit() {
  	this.signupForm=this.fbuilder.group({
  		name:['rahul',[Validators.required]],
  		email:['',[Validators.required,Validators.email]],
  		password:['',[Validators.required]],
  		cpassword:['',[Validators.required]],
  		mobilenumber:['',[Validators.required]]
  	})
  }
  AddData(abc){
  	// console.log(abc);
  	// console.log(abc.value);
  	if(abc.value.password != abc.value.cpassword){
  		this.status=true
  	}
  	else
  	{
  		this.status=false;
  		// localStorage.setItem('logindetails',JSON.stringify(abc.value));
  		localStorage.setItem('emailid',abc.value.email);
  		localStorage.setItem('password',abc.value.password);

      var mob =abc.value.mobilenumber
      var msg = "Registration Done";

      var str = "http://api.textlocal.in/send/?username=imvijay85@gmail.com&hash=865e78d5c41470269cd7201e2a4d4b86e715617e7fe8a923ea127a695c99d4fb&message="+msg+"&sender=TXTLCL&numbers=91"+mob+"&test=0"

      this.crud.sendSMS(str).subscribe(
        (res)=>{
          console.log(res);
        }
       )
  	}

  }
}
