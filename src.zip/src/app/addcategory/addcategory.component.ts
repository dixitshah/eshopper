import { Component, OnInit } from '@angular/core';
import {CrudService} from'../crud.service';
@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css']
})
export class AddcategoryComponent implements OnInit {

  constructor(private cat:CrudService) { }

  ngOnInit() {
  }
 addcategory(val){
 	this.cat.insert("category",{title:val}).subscribe(
 		(res)=>{
 			console.log(res);
 		}

 		)
 }
}
