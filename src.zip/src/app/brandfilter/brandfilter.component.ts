import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
@Component({
  selector: 'app-brandfilter',
  templateUrl: './brandfilter.component.html',
  styleUrls: ['./brandfilter.component.css']
})
export class BrandfilterComponent implements OnInit {
	public productdata =[];
  constructor(private route: ActivatedRoute, private abc:Http) {
  	// console.log(this.route.params._value.xyz);


   }

  ngOnInit() {
 //  	var id=this.route.params._value.xyz;
 //  		this.abc.get("http://localhost:5000/product").subscribe(
 //  		(product)=>{
 //  			// console.log(product.json());
	//   		var pro=product.json();
	//   		for(var ans in pro){
	//   			// console.log(ans);
	//   			// console.log(typeof pro[ans]);
	//   			// console.log(typeof pro[ans].category_id);
	//   			if(pro[ans].brand_id == Number(this.route.params._value.xyz)){

	//   				this.productdata.push(pro[ans]);
	//   			}
	//   		}	
	//   		console.log(this.productdata);
 //  		}
	// );

  }

}
