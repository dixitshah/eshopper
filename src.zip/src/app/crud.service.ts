import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { map } from 'rxjs/operators';
import { Subject } from 'rxjs';
// import { Subject } from 'rxjs/subject';
@Injectable({
  providedIn: 'root'
})
export class CrudService {

public dataSource = new Subject();

private URL="http://localhost:5000/";
  constructor(private http:Http) { }
  select(path){
  	return this.http.get(this.URL+path).pipe(
  		
  		map((res)=>{
  			// console.log(res.json());
  			return res.json();
  		})
  		);
  }
  insert(path,data){
  	console.log(data);
  	return this.http.post(this.URL+path,data).pipe(
  			map((res)=>{
  			// console.log(res.json());
  			return res.json();
  		})


  		)
  }

  filter_brand(id){
    this.dataSource.next(id)
  }

  sendSMS(url){
    return this.http.get(url).pipe(
      
      map((res)=>{
        // console.log(res.json());
        return res.json();
      })
      );
  }
}
