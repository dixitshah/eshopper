import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { Http } from '@angular/http';
@Component({
  selector: 'app-cartcomponent',
  templateUrl: './cartcomponent.component.html',
  styleUrls: ['./cartcomponent.component.css']
})
export class CartcomponentComponent implements OnInit {
	newpro = []
  constructor(private cartshow: CookieService, private xyz:Http ) { }
  
  ngOnInit() {
  	//1,2,3
  	var rec=this.cartshow.get("product");
  	// console.log(rec);
  	var recarr = rec.split(",");
  	// ["1","2","3"]
  	// console.log(recarr)
  	this.xyz.get("http://localhost:5000/product").subscribe(
  		(product)=>{

  			var productdata=product.json();
  			// console.log(productdata);
  			for(var ans in productdata){
  				// console.log(ans)
  				// console.log(productdata[ans])
  				// console.log(productdata[ans].id)
  				// console.log(typeof productdata[ans].id)

  				var pos = recarr.indexOf(productdata[ans].id.toString())
  				// console.log(pos);

  				if(pos>-1){
  					this.newpro.push(productdata[ans])
  				}
  			}
  			// console.log(this.newpro)
  		}
	);
  }

  deletefromcart(id,ev){
  	// console.log(ev);
  	ev.preventDefault();
  	// console.log(id);
  	var rec=this.cartshow.get("product");
  	// console.log(rec);
  	//1,2,3,4
  	var newrec = rec.split(",")
  	// console.log(newrec)
  	// ["1","2","3","4"]
  	var pos = newrec.indexOf(id.toString());
  	// console.log(pos);
  	//pos=>1
  	newrec.splice(pos,1)
  	// console.log(newrec)
  	//["1","3","4"]
  	var newdata = newrec.join(",")
  	// console.log(newdata)
  	// 1,3,4
  	this.cartshow.set("product",newdata);
  	ev.target.parentNode.parentNode.parentNode.parentNode.style.display="none";
  }

}
