import { Component, OnInit } from '@angular/core';
import { Router,Act } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  		localStorage.removeItem('emailid');
  		localStorage.removeItem('password');
  		localStorage.removeItem('status');
  		this.router.navigate(['/login']);
  }

}
